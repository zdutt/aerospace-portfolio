﻿# File map

## src
- dutt\aerospace-portfolio\_ai_out\src\app\about\page.tsx (1.4 KB)
- dutt\aerospace-portfolio\_ai_out\src\app\favicon.ico (25.3 KB)
- dutt\aerospace-portfolio\_ai_out\src\app\globals.css (0.5 KB)
- dutt\aerospace-portfolio\_ai_out\src\app\layout.tsx (1.5 KB)
- dutt\aerospace-portfolio\_ai_out\src\app\page.tsx (1.7 KB)
- dutt\aerospace-portfolio\_ai_out\src\app\projects\page.tsx (0.6 KB)
- dutt\aerospace-portfolio\_ai_out\src\components\Navbar.tsx (1.3 KB)
- dutt\aerospace-portfolio\_ai_out\src\components\ProjectCard.tsx (1.5 KB)
- dutt\aerospace-portfolio\_ai_out\src\components\ResumeTimeline.tsx (9.6 KB)
- dutt\aerospace-portfolio\_ai_out\src\components\SiteHeader.tsx (1.9 KB)
- dutt\aerospace-portfolio\_ai_out\src\components\Starfield.tsx (13.8 KB)
- dutt\aerospace-portfolio\_ai_out\src\components\ui\badge.tsx (0.5 KB)
- dutt\aerospace-portfolio\_ai_out\src\components\ui\button.tsx (1.4 KB)
- dutt\aerospace-portfolio\_ai_out\src\components\ui\card.tsx (1.2 KB)
- dutt\aerospace-portfolio\_ai_out\src\lib\projects.ts (1.1 KB)

## public
- dutt\aerospace-portfolio\_ai_out\public\file.svg (0.4 KB)
- dutt\aerospace-portfolio\_ai_out\public\globe.svg (1 KB)
- dutt\aerospace-portfolio\_ai_out\public\next.svg (1.3 KB)
- dutt\aerospace-portfolio\_ai_out\public\resume\Dutton-Resume-2025.pdf (147.9 KB)
- dutt\aerospace-portfolio\_ai_out\public\vercel.svg (0.1 KB)
- dutt\aerospace-portfolio\_ai_out\public\window.svg (0.4 KB)

